package com.example.rickandmorty

import androidx.fragment.app.Fragment

class LocationFragment : Fragment (R.layout.fragment_location   ) {
}