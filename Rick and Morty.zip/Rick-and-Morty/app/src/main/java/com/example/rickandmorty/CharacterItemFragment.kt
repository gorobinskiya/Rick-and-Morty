package com.example.rickandmorty

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide


class CharacterItemFragment : Fragment(R.layout.chracter_item_fragment) {
    lateinit var displayMessage: Character

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        displayMessage = arguments?.getSerializable("message") as Character

        view.findViewById<TextView>(R.id.textView).text = displayMessage.toString()

        Glide.with(requireContext()).load(displayMessage.imageUrl)
            .into(view.findViewById<ImageView>(R.id.character_image))
    }

    companion object {
        fun newInstance(character: Character) = CharacterItemFragment().apply {
            arguments = Bundle().apply {
                putSerializable("message", character)
            }
        }

        const val TAG = "FRAGMENT_CHARACTER_TAG"
    }
}