package com.example.rickandmorty.retrofit

import com.example.rickandmorty.data.Character
import retrofit2.Call
import retrofit2.http.GET

interface RetroServiceInterface {

    @GET("character")
    fun getCharacterList(): Call<List<Character>>
}