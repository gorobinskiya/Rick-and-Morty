import com.example.rickandmorty.retrofit.RetroServiceInterface
import com.example.rickandmorty.retrofit.RetrofitClient

object Common {
    private val BASE_URL = "https://rickandmortyapi.com/api/"
    val retrofitServiceInterface: RetroServiceInterface
        get() = RetrofitClient.getClient(BASE_URL).create(RetroServiceInterface::class.java)
}