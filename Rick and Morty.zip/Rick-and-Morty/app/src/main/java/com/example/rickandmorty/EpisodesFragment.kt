package com.example.rickandmorty

import androidx.fragment.app.Fragment

class EpisodesFragment : Fragment(R.layout.episodes_fragment) {
}