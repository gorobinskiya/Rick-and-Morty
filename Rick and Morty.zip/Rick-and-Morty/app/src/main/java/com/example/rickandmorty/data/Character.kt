package com.example.rickandmorty.data

data class Character(
                          val name: String,
                          val species: String,
                          val status: String,
                          val gender: String)
