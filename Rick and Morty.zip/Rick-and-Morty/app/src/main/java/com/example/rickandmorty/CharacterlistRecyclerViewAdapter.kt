package com.example.rickandmorty

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide


class CharacterlistRecyclerViewAdapter(
    var data: MutableList<com.example.rickandmorty.data.Character>,
   // val onClick: (Character) -> Unit
) :
    RecyclerView.Adapter<CharacterlistRecyclerViewAdapter.CharacterViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CharacterViewHolder {
        val characterRowView =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.character_item_layout, parent, false)
        return CharacterViewHolder(characterRowView)
    }

    override fun onBindViewHolder(holder: CharacterViewHolder, position: Int) {
        val characterName = data[position].name
        holder.characterNameTextView.text = characterName
//        holder.itemView.setOnClickListener { onClick(data[position]) }
//        Glide.with(holder.itemView.context).load(data[position].imageUrl).into(holder.avatarImage)
    }

    override fun getItemCount(): Int {
        return data.size
    }


    class CharacterViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val characterNameTextView: TextView = itemView.findViewById(R.id.char_name)
        val avatarImage: ImageView = itemView.findViewById(R.id.char_image)
    }

}