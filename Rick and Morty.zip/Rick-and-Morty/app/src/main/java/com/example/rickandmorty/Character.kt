//package com.example.rickandmorty
//
//import java.io.Serializable
//
//data class Character(
//    val name: String,
//    val species: String,
//    val status: String,
//    val gender: String
//) : Serializable {
//    override fun toString(): String {
//        return "$name $species $status $gender" ;
//    }
//
//    val imageUrl = "https://picsum.photos/200?random=${(0..150).random()}"
//}
