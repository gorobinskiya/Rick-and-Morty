package com.example.rickandmorty

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class CharactersAcivity : AppCompatActivity(), CharacterslistFragment.OnItemNameClickListener {

    private val episodesFragment = EpisodesFragment()
    private val locationFragment = LocationFragment()
    private val characterslistFragment = CharacterslistFragment()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_characters_acivity)
        replaceFragment(characterslistFragment)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_nav)
        bottomNav.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.nav_char -> replaceFragment(characterslistFragment)
                R.id.nav_episodes -> replaceFragment(episodesFragment)
                R.id.nav_location -> replaceFragment(locationFragment)
            }
            true
        }


//        supportFragmentManager.beginTransaction().run {
//            val fragmentCharacters = CharacterslistFragment.newInstance()
//            replace(R.id.fragment_container, fragmentCharacters, CharacterslistFragment.TAG)
//            this.commit()
//        }

    }

    private fun replaceFragment (fragment:Fragment){
        if (fragment!=null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, fragment)
            transaction.commit()
        }
    }

    override fun OnItemNameClicked(character: Character) {
        supportFragmentManager.beginTransaction().run {
            val fragmentCharacter = CharacterItemFragment.newInstance(character)
            replace(R.id.fragment_container, fragmentCharacter, CharacterItemFragment.TAG)
            addToBackStack(CharacterItemFragment.TAG)
            this.commit()
        }
    }
}