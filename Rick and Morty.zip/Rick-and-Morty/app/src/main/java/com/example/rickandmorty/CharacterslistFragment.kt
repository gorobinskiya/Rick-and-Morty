package com.example.rickandmorty

import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.*

class CharacterslistFragment : Fragment(R.layout.fragment_characters) {

    private lateinit var itemNameClickListener: OnItemNameClickListener

    override fun onAttach(context: Context) {
        super.onAttach(context)
        itemNameClickListener = context as OnItemNameClickListener

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val characterList = mutableListOf<Character>().apply {
            repeat(150) {
//                add(
//                    Character(
//
//                        "${UUID.randomUUID()}",
//                        "${UUID.randomUUID()}",
//                        "${UUID.randomUUID()}",
//                        "${UUID.randomUUID()}"
//
//                    )
//                )
            }
        }

        val characterListView = view.findViewById<RecyclerView>(R.id.charactersRecycleView)
        val gridLayoutManager = GridLayoutManager(context, 2, LinearLayoutManager.VERTICAL, false)
        characterListView.layoutManager = gridLayoutManager
        val characterListAdapter = CharacterlistRecyclerViewAdapter(
            characterList,
            { itemNameClickListener.OnItemNameClicked(it) })

        characterListView.adapter = characterListAdapter
    }

    interface OnItemNameClickListener {
        fun OnItemNameClicked(character: Character)
    }

    companion object {

        fun newInstance() = CharacterslistFragment()

        const val TAG = "FRAGMENTS_CHARACTER_TAG"
    }
}